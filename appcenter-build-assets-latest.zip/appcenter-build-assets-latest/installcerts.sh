#!/bin/sh

BUILD_SRC_ROOT=$BUILD_SOURCESDIRECTORY
CERT_FILENAME="ios_cert"

if [ ! -z "$3" ]; then
	BUILD_SRC_ROOT="$3"
fi

if [ ! -z "$4" ]; then
	CERT_FILENAME="$4"
fi

if [ -z "$1" ]; then
	echo "P12 certification is missing."
	exit 1
fi

if [ -z "$2" ]; then
	echo "Provisioning profile is missing."
	exit 1
fi

if [ -z "$BUILD_SRC_ROOT" ]; then
	echo "Source code root directory is not specified."
	exit 1
fi

# Create .certs directory under the source root if it is not existed
[ -d "$BUILD_SRC_ROOT/.certs" ] || mkdir -p "$BUILD_SRC_ROOT/.certs"

# Decode the base64-encoded certificate contexts to the files
echo "$1" | base64 --decode > "$BUILD_SRC_ROOT/.certs/$CERT_FILENAME.p12"
echo "$2" | base64 --decode > "$BUILD_SRC_ROOT/.certs/$CERT_FILENAME.mobileprovision"

exit 0