SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"

find $SCRIPTPATH -type f -print0 | xargs -0 grep -s -l -E '^#!/(usr/)?bin' | xargs chmod +x

GRADLE_INIT_SCRIPT_VM_PLUGINS_PATH="$SCRIPTPATH/gradle-init-script-plugins"

echo "Reinstalling Gradle init script plugins from ${GRADLE_INIT_SCRIPT_VM_PLUGINS_PATH}..."

GRADLE_HOME_DIR=${GRADLE_USER_HOME:-$HOME/.gradle}
# cleanup any existing files
if [ -d "$GRADLE_HOME_DIR/init.d" ]; then
  rm -rf "$GRADLE_HOME_DIR/init.d"
fi

mkdir -p "$GRADLE_HOME_DIR/init.d"

cp -R "${GRADLE_INIT_SCRIPT_VM_PLUGINS_PATH}/." "$GRADLE_HOME_DIR/init.d"