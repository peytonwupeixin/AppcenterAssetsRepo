#!/bin/sh

version=$1

NVM_DIR="$HOME/.nvm"

if [ ! -d "$NVM_DIR" ]; then
  echo "NVM is not installed. Installing now..."
  # Download and install NVM
  curl --silent https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash 2>&1
  echo "NVM installed."
fi

echo "Loading NVM."

[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

if [ "$version" == "nvmrc" ] ; then
    # Install node from nvmrc
    nvm use --delete-prefix --silent 2>&1
    nvm install 2>&1
else
    # Try to use specified node version
    resolvedVersion=${version//node/v}
    nvm use --delete-prefix $resolvedVersion --silent 2>&1
    nvm install $resolvedVersion 2>&1
fi

nvm alias default $(nvm current)

echo "Node version: $(node -v)"
echo "npm version: $(npm -v)"

# Throw `PATH` to the next step (AzDO specific)
echo '##vso[task.setvariable variable=PATH;]'$PATH