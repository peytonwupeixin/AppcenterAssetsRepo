#!/bin/bash

# Secure files uploading script
# It uploads given file to the secure storage and saves its id to variable group "Sonoma.SecureMigration"
#
# PROJECT_URL - url or Sonoma project, e.g. https://msft-sonoma-int-000000.visualstudio.com
# PROJECT_ID - id of Sonoma project, from tenantInfo.project.id
# USER - user name, from tenantInfo.user
# TOKEN - SP token, from tenantInfo.servicePrincipalToken.tfs
# FILE_NAME - unique name for uploading file
# ORIGINAL_FILE_NAME - unique name for uploading file
# FILE_ENCODED - base64 encoded file contents
# VARIABLE_GROUP_ID - id of "Sonoma.SecureMigration" variable group
# FILE_VARIABLE_KEY - key of variable in Sonoma.SecureMigration" for storing uploaded secure file id
# FILE_TYPE - 1 - provision profile, 2 - certificate
# CERT_PWD - certificate password

PROJECT_URL="$1"
PROJECT_ID="$2"
USER="$3"
TOKEN="$4"
FILE_NAME="$5"
ORIGINAL_FILE_NAME="$6"
FILE_ENCODED="$7"
VARIABLE_GROUP_ID="$8"
FILE_VARIABLE_KEY="$9"
FILE_TYPE="${10}"
CERT_PWD="${11}"

FILE_PATH="./$ORIGINAL_FILE_NAME"

# write encoded content to file
echo "$FILE_ENCODED" | base64 --decode > "$FILE_PATH"

size="$(wc -c <"$FILE_PATH")"
size=$(echo "${size}" | tr -d '[:space:]')
signature=$(openssl sha -sha256 "$FILE_PATH" | sed 's/^.*= //')

# get secure files properties
case $FILE_TYPE in
  1)
    echo "getting profile properties"

    # Opening the certificates
    openssl smime -inform der -in $FILE_PATH -verify -out profiletext.plist
    certs=$(/usr/libexec/PlistBuddy -c 'Print :DeveloperCertificates' -x profiletext.plist)

    # Getting the cert with the latest expiration end date validaty
    latestDate=0
    latestProvCertIndex=0
    total=$(echo $certs | grep -o "<data>" | wc -l)

    echo "Detected $total certificates"
    fingerprints=()

    for (( i=0; i<=$(( $total-1 )); i++ ))
    do   
      provDate=$(date -j -f "%b %d %T %Y %Z" "$(/usr/libexec/PlistBuddy -c "Print DeveloperCertificates:$i" profiletext.plist |openssl x509 -inform der -noout -enddate | sed 's/.*notAfter=\(.*\)$/\1/g')" "+%s")
      fingerprint_value=$(/usr/libexec/PlistBuddy -c "Print DeveloperCertificates:$i" profiletext.plist |openssl x509 -inform der -noout -fingerprint | cut -d= -f 2)
      fingerprints[$i+1]="\"xcode.provisioningProfile.fingerprints.$i\":\"$fingerprint_value\","
      if [ $provDate -ge $latestDate ]; 
      then
        latestDate=$provDate
        latestProvCertIndex=$i
      fi
    done

    # Getting IFileInfoXcodeMobileProvisionDetails
    validityEnd=$latestDate
    fingerPrint=$(/usr/libexec/PlistBuddy -c "Print DeveloperCertificates:$latestProvCertIndex" profiletext.plist |openssl x509 -inform der -noout -fingerprint | cut -d= -f 2)
    validityStart=$(date -j -f "%b %d %T %Y %Z" "$(/usr/libexec/PlistBuddy -c "Print DeveloperCertificates:$latestProvCertIndex" profiletext.plist |openssl x509 -inform der -noout -startdate | sed 's/.*notBefore=\(.*\)$/\1/g')" "+%s")
    certificateName=$(/usr/libexec/PlistBuddy -c "Print DeveloperCertificates:$latestProvCertIndex" profiletext.plist |openssl x509 -inform der -noout -subject | sed 's/^.*CN=//' | sed 's/\/.*$//')
    provName=$(/usr/libexec/PlistBuddy -c 'Print :Name'  profiletext.plist)
    teamIdentifiers=$(/usr/libexec/PlistBuddy -c 'Print :TeamIdentifier'  profiletext.plist | sed -e 1d -e '$d' | tr -d '[:space:]')
    teamIdentifier=${teamIdentifiers[0]}
    profileType="app-store"

    provisionsAllDevices=$(/usr/libexec/PlistBuddy -c 'Print :ProvisionsAllDevices'  profiletext.plist 2>/dev/null)
    exitCode=$? 
    if [ $exitCode == 0 ] && [ $provisionsAllDevices = "true" ];
    then
      profileType="enterprise"    
    else
      exitCode=0
      entitlements=$(/usr/libexec/PlistBuddy -c 'Print :Entitlements'  profiletext.plist 2>/dev/null)
      exitCode=$? 
      if [ $exitCode == 0 ];
      then 
        # entitlements = $(echo $entitlements |  grep = | tr -d ' ')
        for entitlement in $(/usr/libexec/PlistBuddy -c 'Print :Entitlements'  profiletext.plist | grep = | tr -d ' ')
          do
            if [[ $entitlement =~ .*get-task-allow.* ]];
            then
              value=$(echo $entitlement | sed 's/^.*=//')
              if [ $value = true ];
              then
                profileType="development"
              fi 
            fi
          done
      fi
    fi

    # If provisionedDevices exists and its not one of the above it an ad-hoc 
    provisionedDevices=$(/usr/libexec/PlistBuddy -c 'print ":ProvisionedDevices"' profiletext.plist 2>/dev/null)
    exitCode=$? 
    if [ $exitCode == 0 ] && [ "$profileType" = "app-store" ];
    then
      profileType="ad-hoc"
    fi

    patchData="{""\"properties""\":\
      {\
      ""\"signature""\":""\"$signature""\",\
      ""\"size""\":""\"$size""\",\
      ""\"xcode.type""\":""\"provisioningProfile""\",\
      ""\"xcode.provisioningProfile.name""\":""\"$provName""\",\
      ""\"xcode.provisioningProfile.certificateName""\":""\"$certificateName""\",\
      ""\"xcode.provisioningProfile.validityStart""\":""\"$validityStart""\",\
      ""\"xcode.provisioningProfile.validityEnd""\":""\"$validityEnd""\",\
      $(printf "%s" "${fingerprints[@]}") \
      ""\"xcode.provisioningProfile.profileType""\":""\"$profileType""\",\
      ""\"xcode.provisioningProfile.teamIdentifier""\":""\"$teamIdentifier""\",\
      ""\"originalFilename""\":""\"$ORIGINAL_FILE_NAME""\"},\
      ""\"Name""\":""\"$FILE_NAME""\"}"
    ;;
  2)
    echo "getting certificate properties"

    openssl pkcs12 -in "$FILE_PATH" -out keyStore.pem -nodes -password pass:$CERT_PWD
    
    certEndDate=$(openssl x509 -in keyStore.pem -noout -enddate)
    certStartDate=$(openssl x509 -in keyStore.pem -noout -startdate)
    certValidityStart=$(date -j -f "%b %d %T %Y %Z" "$(echo $certStartDate| sed 's/.*notBefore=\(.*\)$/\1/g')" "+%s")
    certValidityEnd=$(date -j -f "%b %d %T %Y %Z" "$(echo $certEndDate | sed 's/.*notAfter=\(.*\)$/\1/g')" "+%s")
    certFingerprint=$(openssl x509 -in keyStore.pem -noout -fingerprint | cut -d= -f 2)
    certName=$(openssl x509 -in keyStore.pem -noout -subject | sed 's/^.*CN=//' | sed 's/\/.*$//')
    
    patchData="{""\"properties""\":\
      {\
      ""\"signature""\":""\"$signature""\",\
      ""\"size""\":""\"$size""\",\
      ""\"xcode.type""\":""\"certificate""\",\
      ""\"xcode.certificate.keyName""\":""\"$certName""\",\
      ""\"xcode.certificate.validityStart""\":""\"$certValidityStart""\",\
      ""\"xcode.certificate.validityEnd""\":""\"$certValidityEnd""\",\
      ""\"xcode.certificate.fingerprint""\":""\"$certFingerprint""\",\
      ""\"originalFilename""\":""\"$ORIGINAL_FILE_NAME""\"},\
      ""\"Name""\":""\"$FILE_NAME""\"}"
    
    ;;
  *) exit 1 ;;
esac

# uploading file to secure storage
uploadResult=$(curl -X POST \
  "$PROJECT_URL/defaultcollection/$PROJECT_ID/_apis/distributedtask/securefiles?name=$FILE_NAME" \
  -H "accept: application/json;api-version=3.2-preview.1" \
  -H "authorization: Bearer $TOKEN" \
  -H "cache-control: no-cache" \
  -H "content-type: application/octet-stream" \
  -H "user-agent: Sonoma (CI) AppID/$APP_ID UserID/$USER" \
  -H "x-tfs-fedauthredirect: Suppress" \
  --data-binary @$FILE_PATH)

# parsing secure file id from response
secureFileId=$(echo $uploadResult | python -c "import sys, json; print json.load(sys.stdin)['id'];")

echo "File uploaded with id $secureFileId"

# getting migration variable group
migrationGroup=$(curl -X GET \
  "$PROJECT_URL/defaultcollection/$PROJECT_ID/_apis/distributedtask/variablegroups/$VARIABLE_GROUP_ID" \
  -H "accept: application/json;api-version=3.2-preview.1" \
  -H "authorization: Bearer $TOKEN" \
  -H "cache-control: no-cache" \
  -H "content-type: application/json" \
  -H "user-agent: Sonoma (CI) AppID/$APP_ID UserID/$USER" \
  -H "x-tfs-fedauthredirect: Suppress")

# save secure file id
migrationGroup=$(echo $migrationGroup | python -c "import sys, json; group = json.load(sys.stdin); group['variables']['$FILE_VARIABLE_KEY']['value'] = \"$secureFileId\"; print json.dumps(group);")

# update migration variable group
curl -X PUT \
  "$PROJECT_URL/defaultcollection/$PROJECT_ID/_apis/distributedtask/variablegroups/$VARIABLE_GROUP_ID" \
  -H "accept: application/json;api-version=3.2-preview.1" \
  -H "authorization: Bearer $TOKEN" \
  -H "cache-control: no-cache" \
  -H "content-type: application/json" \
  -H "user-agent: Sonoma (CI) AppID/$APP_ID UserID/$USER" \
  -H "x-tfs-fedauthredirect: Suppress" \
  -d "$migrationGroup"

echo "uploaded file id saved in Sonoma.SecureMigration"

# update secure file data
curl -X PATCH \
  "$PROJECT_URL/defaultcollection/$PROJECT_ID/_apis/distributedtask/securefiles/$secureFileId" \
  -H "accept: application/json;api-version=3.2-preview.1" \
  -H "authorization: Bearer $TOKEN" \
  -H "cache-control: no-cache" \
  -H "content-type: application/json" \
  -H "user-agent: Sonoma (CI) AppID/$APP_ID UserID/$USER" \
  -H "x-tfs-fedauthredirect: Suppress" \
  -d "$patchData"

echo "uploaded file propeties updated"