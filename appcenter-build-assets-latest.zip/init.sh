SCRIPTPATH="$( cd "$(dirname "$0")" ; pwd -P )"

find $SCRIPTPATH -type f -print0 | xargs -0 grep -s -l -E '^#!/(usr/)?bin' | xargs chmod +x

GRADLE_INIT_SCRIPT_VM_PLUGINS_PATH="$SCRIPTPATH/gradle-init-script-plugins"

echo "Reinstalling Gradle init script plugins from ${GRADLE_INIT_SCRIPT_VM_PLUGINS_PATH}..."

# cleanup any existing files
if [ -d "$HOME/.gradle/init.d" ]; then
  rm -rf "$HOME/.gradle/init.d"
fi

mkdir -p "$HOME/.gradle/init.d"

cp -R "${GRADLE_INIT_SCRIPT_VM_PLUGINS_PATH}/." "$HOME/.gradle/init.d"