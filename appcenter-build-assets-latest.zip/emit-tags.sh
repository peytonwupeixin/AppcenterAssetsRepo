#!/bin/sh

if [ -z "$1" ]; then
    echo "No Sonoma build tags specified."
    exit 0
fi

IFS=","
for tag in $1
do
    if [ -z "$tag" ]; then
        continue
    else
        echo "##vso[build.addbuildtag]$tag"
    fi
done

# HACKHACK: Force Xamarin to use the latest Xcode until we support multiple VMs
echo "##vso[task.setvariable variable=MD_APPLE_SDK_ROOT;]/Applications/Xcode.app"

# HACKHACK: Force Xamarin build to use Mono 4 unless Mono version is set
if [ -z "$DYLD_FALLBACK_LIBRARY_PATH" ]; then
    MONOPREFIX=/Library/Frameworks/Mono.framework/Versions/4
    echo "##vso[task.setvariable variable=DYLD_FALLBACK_LIBRARY_PATH;]$MONOPREFIX/lib:/lib:/usr/lib:$DYLD_LIBRARY_FALLBACK_PATH"
    echo "##vso[task.setvariable variable=PKG_CONFIG_PATH;]$MONOPREFIX/lib/pkgconfig:$MONOPREFIX/share/pkgconfig:$PKG_CONFIG_PATH"
    echo "##vso[task.setvariable variable=PATH;]$MONOPREFIX/bin:$PATH"
fi