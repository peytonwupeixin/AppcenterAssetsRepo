#!/bin/bash

# Secure files migration set state
# Sets state for "Sonoma.SecureMigration"

PROJECT_URL="$1"
PROJECT_ID="$2"
USER="$3"
TOKEN="$4"
VARIABLE_GROUP_ID="$5"
MIGRATION_VARIABLE_KEY="$6"
MIGRATION_STATE="$7"

# get migration group
migrationGroup=$(curl -X GET \
  "$PROJECT_URL/defaultcollection/$PROJECT_ID/_apis/distributedtask/variablegroups/$VARIABLE_GROUP_ID" \
  -H "accept: application/json;api-version=3.2-preview.1" \
  -H "authorization: Bearer $TOKEN" \
  -H "cache-control: no-cache" \
  -H "content-type: application/json" \
  -H "user-agent: Sonoma (CI) AppID/$APP_ID UserID/$USER" \
  -H "x-tfs-fedauthredirect: Suppress")

# set migration state
migrationGroup=$(echo $migrationGroup | python -c "import sys, json; group = json.load(sys.stdin); group['variables']['$MIGRATION_VARIABLE_KEY']['value'] = \"$MIGRATION_STATE\"; print json.dumps(group);")

# update migration variable group
curl -X PUT \
  "$PROJECT_URL/defaultcollection/$PROJECT_ID/_apis/distributedtask/variablegroups/$VARIABLE_GROUP_ID" \
  -H "accept: application/json;api-version=3.2-preview.1" \
  -H "authorization: Bearer $TOKEN" \
  -H "cache-control: no-cache" \
  -H "content-type: application/json" \
  -H "user-agent: Sonoma (CI) AppID/$APP_ID UserID/$USER" \
  -H "x-tfs-fedauthredirect: Suppress" \
  -d "$migrationGroup"